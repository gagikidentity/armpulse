import React from 'react';

export default function Portfolio() {
  const projects = [
    {
      title: "Commercial Reel",
      image: "https://images.unsplash.com/photo-1601506521793-dc748fc80b67?auto=format&fit=crop&w=1600&q=80",
      category: "Advertising"
    },
    {
      title: "Training Course",
      image: "https://images.unsplash.com/photo-1579187707643-35646d22b596?auto=format&fit=crop&w=1600&q=80",
      category: "Education"
    },
    {
      title: "Corporate Video",
      image: "https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=1600&q=80",
      category: "Business"
    },
    {
      title: "Event Coverage",
      image: "https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1600&q=80",
      category: "Events"
    }
  ];

  return (
    <section id="portfolio" className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">Our Portfolio</h2>
          <p className="mt-4 text-xl text-gray-400">Showcasing our best work and creative excellence</p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-2">
          {projects.map((project, index) => (
            <div key={index} className="group relative overflow-hidden rounded-2xl">
              <div className="aspect-w-16 aspect-h-9">
                <img
                  src={project.image}
                  alt={project.title}
                  className="object-cover transition-transform duration-300 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end">
                <div className="p-6">
                  <p className="text-sm text-amber-500">{project.category}</p>
                  <h3 className="mt-2 text-xl font-bold text-white">{project.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}