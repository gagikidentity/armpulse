import React from 'react';
import ServiceCard from './ServiceCard';
import SectionBackground from '../common/SectionBackground';

export default function Services() {
  const services = [
    {
      title: "Ռիլերի պատրաստում",
      description: "Պատվիրեք պրոֆեսիոնալ ռիլեր ձեր բիզնեսի, անձնական բրենդի կամ սոցիալական մեդիայի համար: Ստեղծում ենք յուրահատուկ և գրավիչ բովանդակություն",
      duration: "1-3 օր",
      feature: "Անհատական մոտեցում"
    },
    {
      title: "Ռիլմեյքինգի դասընթացներ",
      description: "Սովորեք ստեղծել գրավիչ և պրոֆեսիոնալ reel-եր՝ փորձառու մասնագետների ուղղորդմամբ: Դասընթացի ավարտին կունենաք ձեր անձնական պորտֆոլիոն",
      duration: "1-3 ամիս",
      feature: "Սկսնակներից մինչև պրոֆեսիոնալներ"
    }
  ];

  return (
    <SectionBackground id="services">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold text-white sm:text-4xl">Մեր ծառայությունները</h2>
      </div>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        {services.map((service, index) => (
          <ServiceCard key={index} {...service} />
        ))}
      </div>
    </SectionBackground>
  );
}