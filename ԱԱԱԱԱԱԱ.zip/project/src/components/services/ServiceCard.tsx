import React, { useState } from 'react';
import { Clock, Users, Phone } from 'lucide-react';
import ServiceModal from './ServiceModal';
import CourseModal from './CourseModal';
import ProductionModal from './ProductionModal';

interface ServiceCardProps {
  title: string;
  description: string;
  duration: string;
  feature: string;
}

export default function ServiceCard({ title, description, duration, feature }: ServiceCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const isCourse = title.includes('դասընթացներ');
  const isProduction = title.includes('պատրաստում');
  const ModalContent = isCourse ? CourseModal : ProductionModal;

  return (
    <>
      <div className="relative group">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-amber-600 to-amber-400 rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative p-6 sm:p-8 bg-gray-800 ring-1 ring-gray-700/5 rounded-lg">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-3 sm:mb-4">{title}</h3>
          <p className="text-gray-400 mb-4 sm:mb-6 text-sm sm:text-base">{description}</p>
          <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-6 mb-4 sm:mb-6">
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-amber-500 mr-2" />
              <span className="text-gray-300 text-sm">{duration}</span>
            </div>
            <div className="flex items-center">
              <Users className="h-5 w-5 text-amber-500 mr-2" />
              <span className="text-gray-300 text-sm">{feature}</span>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => setIsModalOpen(true)}
              className="w-full sm:w-auto px-6 py-3 bg-amber-500 text-black rounded-md hover:bg-amber-400 transition-colors text-sm sm:text-base font-semibold"
            >
              Իմանալ ավելին
            </button>
            {isCourse && (
              <a
                href="tel:077-79-99-24"
                className="w-full sm:w-auto px-6 py-3 bg-black text-amber-500 border-2 border-amber-500 rounded-md hover:bg-amber-500 hover:text-black transition-colors text-sm sm:text-base font-semibold inline-flex items-center justify-center gap-2"
              >
                <Phone className="h-4 w-4" />
                Գրանցվել դասընթացին
              </a>
            )}
            {isProduction && (
              <a
                href="tel:077-79-99-24"
                className="w-full sm:w-auto px-6 py-3 bg-black text-amber-500 border-2 border-amber-500 rounded-md hover:bg-amber-500 hover:text-black transition-colors text-sm sm:text-base font-semibold inline-flex items-center justify-center gap-2"
              >
                <Phone className="h-4 w-4" />
                Պատվիրել ռիլ
              </a>
            )}
          </div>
        </div>
      </div>

      <ServiceModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <ModalContent />
      </ServiceModal>
    </>
  );
}