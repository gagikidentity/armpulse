import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { lockScroll, unlockScroll } from '../../utils/scrollLock';

interface ServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

export default function ServiceModal({ isOpen, onClose, children }: ServiceModalProps) {
  useEffect(() => {
    const teamSection = document.getElementById('team');
    const portfolioSection = document.getElementById('portfolio');
    const contactSection = document.getElementById('contact');
    
    if (isOpen) {
      lockScroll();
      // Hide unnecessary sections
      if (teamSection) teamSection.style.display = 'none';
      if (portfolioSection) portfolioSection.style.opacity = '0.1';
      if (contactSection) contactSection.style.opacity = '0.1';
    } else {
      unlockScroll();
      // Restore sections
      if (teamSection) teamSection.style.display = '';
      if (portfolioSection) portfolioSection.style.opacity = '';
      if (contactSection) contactSection.style.opacity = '';
    }
    
    return () => {
      unlockScroll();
      // Cleanup
      if (teamSection) teamSection.style.display = '';
      if (portfolioSection) portfolioSection.style.opacity = '';
      if (contactSection) contactSection.style.opacity = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-[9999] isolate flex items-center justify-center p-4"
      aria-labelledby="modal-title" 
      role="dialog" 
      aria-modal="true"
    >
      <div 
        className="fixed inset-0 bg-black/95 backdrop-blur-sm" 
        aria-hidden="true" 
        onClick={onClose}
      />
      
      <div className="relative bg-gray-900 rounded-lg shadow-xl w-full max-w-2xl">
        <button
          type="button"
          className="absolute right-4 top-4 text-gray-400 hover:text-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
          onClick={onClose}
        >
          <X className="h-6 w-6" />
        </button>
        
        <div className="p-6 max-h-[80vh] overflow-y-auto custom-scrollbar">
          {children}
        </div>
      </div>
    </div>
  );
}