import React from 'react';
import { Video, Camera, Plane, Mic, Monitor } from 'lucide-react';
import ProductionFeature from './production/ProductionFeature';
import ProductionSection from './production/ProductionSection';

export default function ProductionModal() {
  return (
    <div className="space-y-6 text-gray-300">
      <h2 className="text-3xl font-bold text-white flex items-center justify-center">
        <Video className="h-8 w-8 text-amber-500 mr-3" />
        🎥 ՌԻԼԵՐԻ ՊԱՏՐԱՍՏՈՒՄ
      </h2>

      <ProductionSection title="ՏԵԽՆԻԿԱԿԱՆ ՍԱՐՔԱՎՈՐՈՒՄՆԵՐ" emoji="📸">
        <div className="space-y-6">
          <div>
            <h4 className="text-lg font-medium text-white mb-3">Տեսախցիկներ</h4>
            <ul className="space-y-3">
              <li>
                <ProductionFeature icon={Camera}>
                  Panasonic Lumix S5 IIX - Ներկայացված է Նեթֆլիքսի ֆիլմերի ստեղծման տեխնիկայի պաշտոնական ցանկում
                </ProductionFeature>
              </li>
              <li>
                <ProductionFeature icon={Plane}>
                  🚁 DJI Mini 3 Pro դրոն
                </ProductionFeature>
              </li>
              <li>
                <ProductionFeature icon={Video}>
                  🎬 Osmo pocket 3 - Հարմար է action նկարահանումների համար
                </ProductionFeature>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-medium text-white mb-3">🛠️ Լրացուցիչ սարքեր</h4>
            <ul className="space-y-3">
              <li>
                <ProductionFeature icon={Mic}>
                  🎙️ DJI Mic բարձր զգայնության միկրոֆոն
                </ProductionFeature>
              </li>
              <li>
                <ProductionFeature icon={Camera}>
                  📷 NEEWER 74 Pro շտատիվ կայուն կադրերի համար
                </ProductionFeature>
              </li>
            </ul>
          </div>
        </div>
      </ProductionSection>

      <ProductionSection title="ՄՈՆՏԱԺԻ ԾԱՌԱՅՈՒԹՅՈՒՆՆԵՐ" emoji="🖥️">
        <div className="space-y-4">
          <div>
            <h4 className="text-lg font-medium text-white mb-3">Մեր մոնտաժի փաթեթը ներառում է</h4>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <li>
                <ProductionFeature icon={Monitor}>
                  🔧 Ընդհանուր մշակում
                </ProductionFeature>
              </li>
              <li>
                <ProductionFeature icon={Mic}>
                  🎶 Ձայնային դիզայն
                </ProductionFeature>
              </li>
              <li>
                <ProductionFeature icon={Monitor}>
                  🌈 Գունային կորեկցիա
                </ProductionFeature>
              </li>
              <li>
                <ProductionFeature icon={Video}>
                  🎵 Լիցենզավորված երաժշտություն
                </ProductionFeature>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-medium text-white mb-3">Մոնտաժի գործիք</h4>
            <ProductionFeature icon={Monitor}>
              💻 DaVinci Resolve պրոֆեսիոնալ ծրագրի օգտագործում
            </ProductionFeature>
          </div>
        </div>
      </ProductionSection>

      <ProductionSection title="ՀԱՏՈՒԿ ԱՌԱՋԱՐԿ" emoji="💥">
        <div className="flex items-center bg-amber-500/10 p-4 rounded-lg">
          <span>Նկարահանման ծավալներից կախված՝ մինչև 30% զեղչ 🔥</span>
        </div>
      </ProductionSection>

      <ProductionSection title="ԻՆՉՈՒ ԸՆՏՐԵԼ ՄԵԶ" emoji="🌟">
        <div className="space-y-4">
          <p>🏆 Պրոֆեսիոնալ որակ՝ յուրաքանչյուր նախագիծ մեզ համար եզակի է և պահանջում է անհատական ստեղծարար լուծումներ</p>
          <p>🕒 Արագ իրականացում՝ ռիլերը պատրաստ են լինում նկարահանումին հաջորդող 1-3 օրերի ընթացքում</p>
          <p>🤝 Անձնական մոտեցում՝ մենք լսում և հասկանում ենք մեր հաճախորդի պահանջները</p>
          <p>💸 Արդյունավետ գնագոյացում՝ մրցունակ գներ և զեղչերի հնարավորություն</p>
        </div>
      </ProductionSection>
    </div>
  );
}