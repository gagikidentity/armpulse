import React from 'react';
import { Camera, Clock, Calendar, Building, Film, Smartphone, Video, Lightbulb, Mic, Edit, Briefcase, Music, Palette, Volume2, Share2, TrendingUp, Users, Target } from 'lucide-react';
import CourseSection from './course/CourseSection';
import CourseFeature from './course/CourseFeature';

export default function CourseModal() {
  return (
    <div className="space-y-6 text-gray-300">
      <h2 className="text-3xl font-bold text-white flex items-center justify-center">
        <Camera className="h-8 w-8 text-amber-500 mr-3" />
        🎥 ՌԻԼՄԵՅՔԻՆԳԻ ԴԱՍԸՆԹԱՑ
      </h2>

      <CourseSection title="ԴԱՍԸՆԹԱՑԻ ԿԱԶՄԱԿԵՐՊՈՒՄ" emoji="🎓">
        <ul className="space-y-3">
          <li>
            <CourseFeature icon={Clock}>
              🕒 Տևողությունը՝ 1-2 ամիս
            </CourseFeature>
          </li>
          <li>
            <CourseFeature icon={Calendar}>
              📅 Հաճախականությունը՝ շաբաթական 3 անգամ (1.5-2 ժամ)
            </CourseFeature>
          </li>
          <li>
            <CourseFeature icon={Clock}>
              ⏱️ Ճկուն ժամանակացույց՝ առավոտյան և երեկոյան խմբեր
            </CourseFeature>
          </li>
          <li>
            <CourseFeature icon={Building}>
              🏢 Դասերն անցկացվում են օֆլայն և օնլայն ձևաչափերով
            </CourseFeature>
          </li>
        </ul>
      </CourseSection>

      <CourseSection title="ԴԱՍԸՆԹԱՑԻ ԾՐԱԳԻՐ" emoji="📚">
        <div className="space-y-6">
          <div>
            <h4 className="text-lg font-medium text-white mb-3">Փուլ 1. Նկարահանման հիմունքներ</h4>
            <ul className="space-y-2">
              <li>
                <CourseFeature icon={Film}>
                  🎥 Filmmaking-ի հիմնական սկզբունքներ
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Smartphone}>
                  📱 Տեսախցիկի և սմարթֆոնի պրոֆեսիոնալ կարգավորումներ
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Camera}>
                  🎬 Նկարահանման տեխնիկայի ընտրություն և կիրառում
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Lightbulb}>
                  💡 Լուսավորության տեխնիկաներ և սարքավորումներ
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Mic}>
                  🎤 Ձայնագրման սարքավորումների կիրառում
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Edit}>
                  ✍️ Սցենարի մշակման հմտություններ
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Briefcase}>
                  💼 Բիզնես հմտություններ՝ գնագոյացում և հաճախորդների սպասարկում
                </CourseFeature>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-medium text-white mb-3">Փուլ 2. Մոնտաժ և պոստպրոդակշն</h4>
            <ul className="space-y-2">
              <li>
                <CourseFeature icon={Video}>
                  🎬 Մասնագիտական մոնտաժային ծրագրերի տիրապետում
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Music}>
                  🎵 Երաժշտական ձևավորում
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Palette}>
                  🎨 Գունային գրեյդինգ և կորեկցիա
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Volume2}>
                  🔊 Ձայնային դիզայն և մշակում
                </CourseFeature>
              </li>
              <li>
                <CourseFeature icon={Share2}>
                  📤 Վիդեոների էքսպորտ տարբեր ֆորմատներով
                </CourseFeature>
              </li>
            </ul>
          </div>
        </div>
      </CourseSection>

      <CourseSection title="ԻՆՉՈ՞Ւ ԸՆՏՐԵԼ ՄԵՐ ԴԱՍԸՆԹԱՑԸ" emoji="🌟">
        <ul className="space-y-2">
          <li>
            <CourseFeature icon={TrendingUp}>
              📈 Ընդամենը 1 ամսում դառնալ լավ հիմքով սկսնակ Reel մասնագետ
            </CourseFeature>
          </li>
          <li>
            <CourseFeature icon={Users}>
              👨‍🏫 Փորձառու մասնագետների անմիջական ղեկավարություն
            </CourseFeature>
          </li>
          <li>
            <CourseFeature icon={Video}>
              💪 Պրակտիկ հմտությունների ձեռքբերում և համատեղ 1 ռիլի պատրաստում
            </CourseFeature>
          </li>
          <li>
            <CourseFeature icon={Target}>
              🎯 Շուկայի պահանջներին համապատասխան ուսուցում
            </CourseFeature>
          </li>
        </ul>
      </CourseSection>
    </div>
  );
}