import React from 'react';
import { Play, ChevronRight } from 'lucide-react';
import { translations } from '../constants/translations';

export default function Hero() {
  const { hero } = translations;
  
  return (
    <div id="home" className="relative min-h-screen flex items-center justify-center">
      <div className="absolute inset-0 overflow-hidden">
        <video
          autoPlay
          loop
          muted
          className="absolute min-w-full min-h-full object-cover"
          style={{ filter: 'brightness(0.4)' }}
        >
          <source src="https://player.vimeo.com/external/459389137.hd.mp4?s=865d2c0ec77b5d11f419a9a5b4f26e4f9b2c35fb" type="video/mp4" />
        </video>
      </div>
      
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-8">
          <span className="block">{hero.title}</span>
          <span className="block text-amber-500 mt-2">{hero.subtitle}</span>
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          {hero.description}
        </p>
        <div className="mt-10 flex justify-center gap-x-6">
          <a href="#services" className="rounded-md bg-amber-500 px-6 py-3 text-lg font-semibold text-black shadow-sm hover:bg-amber-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400 flex items-center">
            {hero.buttons.services} <ChevronRight className="ml-2 h-5 w-5" />
          </a>
          <a href="#portfolio" className="rounded-md bg-black/50 backdrop-blur-sm px-6 py-3 text-lg font-semibold text-white shadow-sm ring-1 ring-amber-500 hover:bg-black/70 flex items-center">
            {hero.buttons.portfolio} <Play className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>
    </div>
  );
}