import { supabase } from '../lib/supabase';
import { uploadImage, getImagePath } from './upload/uploadService';

export const uploadTeamMemberImage = async (memberId: string, imageFile: File): Promise<string> => {
  try {
    const filePath = getImagePath(memberId, imageFile);
    const publicUrl = await uploadImage(imageFile, filePath);

    const { error: dbError } = await supabase
      .from('team_member_images')
      .insert({
        member_id: memberId,
        image_url: publicUrl
      });

    if (dbError) {
      throw new Error('db_update_failed');
    }

    return publicUrl;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'auth_required') {
        throw new Error('auth_required');
      }
      console.error('Error uploading image:', error);
      throw new Error(error.message);
    }
    throw error;
  }
};

export const getTeamMemberImage = async (memberId: string): Promise<string | null> => {
  try {
    const { data, error } = await supabase
      .from('team_member_images')
      .select('image_url')
      .eq('member_id', memberId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error) {
      console.warn('Error fetching image:', error);
      return null;
    }

    return data?.image_url || null;
  } catch (error) {
    console.error('Error fetching image:', error);
    return null;
  }
};