export const isValidVideoUrl = (url: string): boolean => {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return urlObj.protocol === 'https:' && 
           (urlObj.hostname.includes('vimeo.com') || 
            urlObj.hostname.includes('player.vimeo.com'));
  } catch {
    return false;
  }
};

export const getVideoThumbnail = (videoUrl: string, fallbackImage: string): string => {
  if (!videoUrl) return fallbackImage;
  // For now, return fallback image if video URL is invalid
  return fallbackImage;
};