import { compressImage } from './imageProcessing';

const STORAGE_KEYS = {
  TEAM_PHOTOS: 'team_photos',
  PORTFOLIO_VIDEOS: 'portfolio_videos',
} as const;

interface AssetMetadata {
  lastModified: number;
  size: number;
  type: string;
  optimized: boolean;
}

interface StoredAsset {
  data: string;
  metadata: AssetMetadata;
}

// Asset cache management
const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days

export const clearExpiredAssets = () => {
  const now = Date.now();
  Object.values(STORAGE_KEYS).forEach(key => {
    try {
      const assets = JSON.parse(localStorage.getItem(key) || '{}');
      const filtered = Object.entries(assets).reduce((acc, [id, asset]) => {
        if (now - (asset as StoredAsset).metadata.lastModified < CACHE_DURATION) {
          acc[id] = asset;
        }
        return acc;
      }, {} as Record<string, StoredAsset>);
      localStorage.setItem(key, JSON.stringify(filtered));
    } catch (error) {
      console.warn(`Failed to clear expired assets for ${key}:`, error);
    }
  });
};

// Team photos management
export const storeTeamPhoto = async (memberId: string, photoData: string): Promise<string> => {
  try {
    const optimizedPhoto = await compressImage(photoData);
    const asset: StoredAsset = {
      data: optimizedPhoto,
      metadata: {
        lastModified: Date.now(),
        size: optimizedPhoto.length,
        type: 'image/jpeg',
        optimized: true
      }
    };

    const photos = JSON.parse(localStorage.getItem(STORAGE_KEYS.TEAM_PHOTOS) || '{}');
    photos[memberId] = asset;
    localStorage.setItem(STORAGE_KEYS.TEAM_PHOTOS, JSON.stringify(photos));
    return optimizedPhoto;
  } catch (error) {
    console.warn('Failed to store team photo:', error);
    return photoData; // Return original if optimization fails
  }
};

export const getTeamPhoto = (memberId: string): string | null => {
  try {
    const photos = JSON.parse(localStorage.getItem(STORAGE_KEYS.TEAM_PHOTOS) || '{}');
    return photos[memberId]?.data || null;
  } catch {
    return null;
  }
};

// Portfolio video management
export const storePortfolioVideo = (videoId: string, videoData: string): void => {
  try {
    const asset: StoredAsset = {
      data: videoData,
      metadata: {
        lastModified: Date.now(),
        size: videoData.length,
        type: 'video/mp4',
        optimized: false // Videos are not optimized client-side
      }
    };

    const videos = JSON.parse(localStorage.getItem(STORAGE_KEYS.PORTFOLIO_VIDEOS) || '{}');
    videos[videoId] = asset;
    localStorage.setItem(STORAGE_KEYS.PORTFOLIO_VIDEOS, JSON.stringify(videos));
  } catch (error) {
    console.warn('Failed to store portfolio video:', error);
  }
};

export const getPortfolioVideo = (videoId: string): string | null => {
  try {
    const videos = JSON.parse(localStorage.getItem(STORAGE_KEYS.PORTFOLIO_VIDEOS) || '{}');
    return videos[videoId]?.data || null;
  } catch {
    return null;
  }
};

// Initialize cache cleanup
clearExpiredAssets();
setInterval(clearExpiredAssets, 24 * 60 * 60 * 1000); // Clean daily