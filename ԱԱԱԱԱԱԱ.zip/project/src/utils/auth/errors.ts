export const AUTH_ERRORS = {
  INVALID_CREDENTIALS: 'invalid_credentials',
  NETWORK_ERROR: 'network_error',
  RATE_LIMIT: 'rate_limit',
  SERVER_ERROR: 'server_error'
} as const;

export const getAuthErrorMessage = (code: string): string => {
  switch (code) {
    case AUTH_ERRORS.INVALID_CREDENTIALS:
      return 'Սխալ էլ․ հասցե կամ գաղտնաբառ';
    case AUTH_ERRORS.NETWORK_ERROR:
      return 'Կապի խնդիր։ Ստուգեք ձեր ինտերնետ կապը';
    case AUTH_ERRORS.RATE_LIMIT:
      return 'Շատ փորձեր։ Խնդրում ենք սպասել մի քանի րոպե';
    case AUTH_ERRORS.SERVER_ERROR:
      return 'Սերվերի սխալ։ Փորձեք կրկին';
    default:
      return 'Անհայտ սխալ է տեղի ունեցել';
  }
};