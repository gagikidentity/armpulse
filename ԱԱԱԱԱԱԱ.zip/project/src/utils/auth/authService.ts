import { supabase } from '../../lib/supabase';
import { AUTH_ERRORS } from './errors';

export const signIn = async (email: string, password: string) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      if (error.message.includes('Invalid login credentials')) {
        throw new Error(AUTH_ERRORS.INVALID_CREDENTIALS);
      }
      if (error.message.includes('Too many requests')) {
        throw new Error(AUTH_ERRORS.RATE_LIMIT);
      }
      throw new Error(AUTH_ERRORS.SERVER_ERROR);
    }

    return data;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    if (!navigator.onLine) {
      throw new Error(AUTH_ERRORS.NETWORK_ERROR);
    }
    throw new Error(AUTH_ERRORS.SERVER_ERROR);
  }
};

export const checkAuth = async () => {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;
    return session;
  } catch (error) {
    console.error('Auth check failed:', error);
    return null;
  }
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};