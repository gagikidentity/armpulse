import { compressImage } from './imageProcessing';

const STORAGE_KEYS = {
  TEAM_IMAGES: 'team_images'
} as const;

const MAX_IMAGES = 5; // Maximum number of images to store
const MAX_IMAGE_SIZE = 500 * 1024; // 500KB per image

export const getStoredImages = (): Record<string, string> => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.TEAM_IMAGES);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
};

export const storeImage = async (memberId: string, imageData: string) => {
  try {
    // Compress image before storing
    const compressedImage = await compressImage(imageData, 400, 400, 0.6);
    
    // Check compressed image size
    const imageSize = new Blob([compressedImage]).size;
    if (imageSize > MAX_IMAGE_SIZE) {
      console.warn('Image too large even after compression');
      return imageData;
    }

    // Get current images
    const images = getStoredImages();
    
    // If we have too many images, remove the oldest ones
    const imageIds = Object.keys(images);
    if (imageIds.length >= MAX_IMAGES) {
      const idsToRemove = imageIds.slice(0, imageIds.length - MAX_IMAGES + 1);
      idsToRemove.forEach(id => delete images[id]);
    }

    // Add new image
    images[memberId] = compressedImage;
    
    try {
      localStorage.setItem(STORAGE_KEYS.TEAM_IMAGES, JSON.stringify(images));
      return compressedImage;
    } catch (storageError) {
      // If storage fails, try to store just this image
      localStorage.setItem(STORAGE_KEYS.TEAM_IMAGES, JSON.stringify({
        [memberId]: compressedImage
      }));
      return compressedImage;
    }
  } catch (error) {
    console.warn('Failed to store image:', error);
    return imageData; // Return original if compression fails
  }
};