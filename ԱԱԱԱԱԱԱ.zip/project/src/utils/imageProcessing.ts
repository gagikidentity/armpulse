interface ImageDimensions {
  width: number;
  height: number;
}

const getOptimalDimensions = (
  originalWidth: number, 
  originalHeight: number, 
  maxWidth = 800,
  maxHeight = 1200
): ImageDimensions => {
  let width = originalWidth;
  let height = originalHeight;

  if (width > maxWidth) {
    height = Math.round((height * maxWidth) / width);
    width = maxWidth;
  }

  if (height > maxHeight) {
    width = Math.round((width * maxHeight) / height);
    height = maxHeight;
  }

  return { width, height };
};

export const compressImage = async (
  imageData: string, 
  maxWidth = 800,
  maxHeight = 1200,
  quality = 0.7
): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => {
      const { width, height } = getOptimalDimensions(img.width, img.height, maxWidth, maxHeight);
      
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Failed to get canvas context'));
        return;
      }
      
      // Apply smooth scaling
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      
      // Draw image with proper scaling
      ctx.drawImage(img, 0, 0, width, height);
      
      // Convert to JPEG with specified quality
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = imageData;
  });
};

export const generateResponsiveImages = async (
  imageData: string,
  sizes = [400, 800, 1200]
): Promise<Record<number, string>> => {
  const results: Record<number, string> = {};
  
  for (const size of sizes) {
    try {
      results[size] = await compressImage(imageData, size, size);
    } catch (error) {
      console.warn(`Failed to generate ${size}px version:`, error);
    }
  }
  
  return results;
};