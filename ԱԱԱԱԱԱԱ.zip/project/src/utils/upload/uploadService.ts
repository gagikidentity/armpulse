import { supabase } from '../../lib/supabase';
import { compressImage } from './imageCompression';
import { validateImage } from './validation';
import { STORAGE_BUCKET, STORAGE_FOLDER } from './constants';

export const uploadImage = async (file: File, path: string): Promise<string> => {
  // Validate image
  const validationError = validateImage(file);
  if (validationError) {
    throw new Error(validationError);
  }

  try {
    // Compress image
    const processedFile = await compressImage(file);
    
    // Upload to storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(path, processedFile, {
        cacheControl: '3600',
        upsert: true,
        contentType: processedFile.type
      });

    if (uploadError) {
      console.error('Storage upload error:', uploadError);
      throw new Error('upload_failed');
    }

    if (!uploadData?.path) {
      throw new Error('upload_failed');
    }

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(STORAGE_BUCKET)
      .getPublicUrl(uploadData.path);

    if (!publicUrl) {
      throw new Error('url_generation_failed');
    }

    return publicUrl;
  } catch (error) {
    console.error('Upload process error:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('upload_failed');
  }
};

export const getImagePath = (id: string, file: File): string => {
  const timestamp = Date.now();
  const randomString = Math.random().toString(36).substring(7);
  const fileExt = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const safeId = id.replace(/[^a-zA-Z0-9-]/g, '');
  const fileName = `${safeId}_${timestamp}_${randomString}.${fileExt}`;
  return `${STORAGE_FOLDER}/${fileName}`;
};