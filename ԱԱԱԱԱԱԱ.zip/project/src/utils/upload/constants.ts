export const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const STORAGE_BUCKET = 'team-images';
export const STORAGE_FOLDER = 'team-photos';