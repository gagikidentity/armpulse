import { MAX_IMAGE_SIZE, ALLOWED_IMAGE_TYPES } from './constants';

export const validateImage = (file: File): string | null => {
  if (!file) {
    return 'Նկար չի ընտրվել';
  }

  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    return 'Թույլատրվում են միայն JPEG, PNG և WebP ֆորմատի նկարներ';
  }

  if (file.size > MAX_IMAGE_SIZE) {
    return 'Նկարի չափը չպետք է գերազանցի 5MB';
  }

  return null;
};