const VIDEO_STORAGE_KEY = 'portfolio_videos';

export interface VideoData {
  id: string;
  title: string;
  category: string;
  videoUrl: string;
  thumbnailUrl: string;
}

export const getStoredVideos = (): Record<string, VideoData> => {
  try {
    const stored = localStorage.getItem(VIDEO_STORAGE_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
};

export const storeVideo = (videoId: string, data: VideoData) => {
  try {
    const videos = getStoredVideos();
    videos[videoId] = data;
    localStorage.setItem(VIDEO_STORAGE_KEY, JSON.stringify(videos));
  } catch (error) {
    console.warn('Failed to store video data:', error);
  }
};