export const getGoogleDriveImageUrl = (imageId: string): string => {
  // Handle full Google Drive URLs
  if (imageId.includes('drive.google.com')) {
    // Handle "view" URLs
    if (imageId.includes('/view')) {
      const matches = imageId.match(/\/d\/(.*?)\/view/);
      if (matches && matches[1]) {
        imageId = matches[1];
      }
    }
    // Handle "file/d" URLs
    else if (imageId.includes('/file/d/')) {
      const matches = imageId.match(/\/file\/d\/(.*?)\//);
      if (matches && matches[1]) {
        imageId = matches[1];
      }
    }
  }
  
  // Return direct access URL
  return `https://drive.google.com/uc?export=view&id=${imageId}`;
};

export const updateGoogleDriveImage = (memberId: string, imageUrl: string): void => {
  try {
    // Get clean image ID
    const imageId = imageUrl.includes('drive.google.com') 
      ? getGoogleDriveImageUrl(imageUrl).split('id=')[1]
      : imageUrl;
    
    const key = `team_member_${memberId}_image`;
    localStorage.setItem(key, imageId);
  } catch (error) {
    console.error('Failed to save image ID:', error);
  }
};

export const getStoredImageId = (memberId: string): string | null => {
  try {
    const key = `team_member_${memberId}_image`;
    return localStorage.getItem(key);
  } catch (error) {
    console.error('Failed to get image ID:', error);
    return null;
  }
};