export const VIMEO_URL_REGEX = /^https:\/\/(?:player\.)?vimeo\.com\/(?:video\/)?(\d+)(?:\?.*)?$/;

export const isVimeoUrl = (url: string): boolean => {
  return VIMEO_URL_REGEX.test(url);
};

export const getVimeoId = (url: string): string | null => {
  const match = url.match(VIMEO_URL_REGEX);
  return match ? match[1] : null;
};

export const formatVimeoUrl = (url: string): string => {
  const id = getVimeoId(url);
  if (!id) return url;
  return `https://player.vimeo.com/video/${id}`;
};

export const validateVimeoUrl = (url: string): string | null => {
  if (!url) return 'URL չի նշվել';
  if (!isVimeoUrl(url)) return 'Խնդրում ենք նշել Vimeo-ի վավեր հղում';
  return null;
};