import { compressImage } from '../imageProcessing';

const STORAGE_KEY = 'team_member_images';

interface StoredImage {
  id: string;
  imageData: string;
  timestamp: number;
}

export const saveImageToLocalStorage = async (memberId: string, imageData: string): Promise<void> => {
  try {
    // Get existing images
    const images: StoredImage[] = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    
    // Remove old image for this member if exists
    const filteredImages = images.filter(img => img.id !== memberId);
    
    // Compress image before storing
    const compressedImage = await compressImage(imageData);
    
    // Add new image
    filteredImages.push({
      id: memberId,
      imageData: compressedImage,
      timestamp: Date.now()
    });
    
    // Save back to localStorage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filteredImages));
  } catch (error) {
    console.error('Failed to save image to localStorage:', error);
  }
};

export const getImageFromLocalStorage = (memberId: string): string | null => {
  try {
    const images: StoredImage[] = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const image = images.find(img => img.id === memberId);
    return image?.imageData || null;
  } catch (error) {
    console.error('Failed to get image from localStorage:', error);
    return null;
  }
};