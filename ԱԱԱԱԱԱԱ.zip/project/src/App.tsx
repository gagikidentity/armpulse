import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/hero/Hero';
import Services from './components/services/Services';
import Team from './components/team/Team';
import Contact from './components/Contact';
import Footer from './components/layout/Footer';
import CallButton from './components/common/CallButton';
import SocialBar from './components/common/SocialBar';

export default function App() {
  return (
    <div className="bg-black min-h-screen">
      <Navbar />
      <CallButton />
      <SocialBar />
      <main>
        <Hero />
        <Services />
        <Team />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}