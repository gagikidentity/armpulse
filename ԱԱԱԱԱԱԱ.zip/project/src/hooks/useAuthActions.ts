import { useState } from 'react';
import { signIn, signOut } from '../utils/auth/authService';
import { getAuthErrorMessage } from '../utils/auth/errors';

export const useAuthActions = (onSuccess?: () => void) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (email: string, password: string) => {
    setLoading(true);
    setError(null);

    try {
      await signIn(email, password);
      onSuccess?.();
    } catch (err) {
      const message = err instanceof Error ? getAuthErrorMessage(err.message) : getAuthErrorMessage('');
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    setLoading(true);
    setError(null);

    try {
      await signOut();
    } catch (err) {
      const message = err instanceof Error ? getAuthErrorMessage(err.message) : getAuthErrorMessage('');
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    handleLogin,
    handleLogout
  };
};