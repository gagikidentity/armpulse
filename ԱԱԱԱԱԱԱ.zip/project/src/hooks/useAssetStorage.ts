import { useState, useEffect } from 'react';
import { getTeamPhoto, getPortfolioVideo } from '../utils/assetStorage';

export const useStoredAsset = (id: string, type: 'photo' | 'video') => {
  const [asset, setAsset] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const loadAsset = async () => {
      try {
        setLoading(true);
        const data = type === 'photo' 
          ? getTeamPhoto(id)
          : getPortfolioVideo(id);
        setAsset(data);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to load asset'));
      } finally {
        setLoading(false);
      }
    };

    loadAsset();
  }, [id, type]);

  return { asset, loading, error };
};