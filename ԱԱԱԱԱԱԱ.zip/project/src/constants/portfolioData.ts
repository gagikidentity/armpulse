import { PortfolioCategory } from '../types/portfolio';

export const portfolioData: PortfolioCategory[] = [
  {
    title: 'Դասընթացներ',
    videos: [
      {
        title: 'Դասընթացի հիմնական պահեր',
        category: 'Ուսուցում',
        videoUrl: 'https://player.vimeo.com/external/459389137.hd.mp4?s=865d2c0ec77b5d11f419a9a5b4f26e4f9b2c35fb',
        thumbnailUrl: 'https://images.unsplash.com/photo-1579187707643-35646d22b596?auto=format&fit=crop&w=1600&q=80'
      },
      {
        title: 'Ուսանողների աշխատանքներ',
        category: 'Պորտֆոլիո',
        videoUrl: 'https://player.vimeo.com/external/434045526.hd.mp4?s=c27abe7aa7d2eee1c9eaf7356f1fa1d5a6869be9',
        thumbnailUrl: 'https://images.unsplash.com/photo-1601506521793-dc748fc80b67?auto=format&fit=crop&w=1600&q=80'
      }
    ]
  },
  {
    title: 'Ռիլեր',
    videos: [
      {
        title: 'Բրենդային ռիլ',
        category: 'Գովազդ',
        videoUrl: 'https://player.vimeo.com/external/403661701.hd.mp4?s=42e2cc5f0b63c5c86f8d6f8f8c1a7d2d8c7c6d6d',
        thumbnailUrl: 'https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=1600&q=80'
      },
      {
        title: 'Իրադարձության լուսաբանում',
        category: 'Միջոցառում',
        videoUrl: 'https://player.vimeo.com/external/434045526.hd.mp4?s=c27abe7aa7d2eee1c9eaf7356f1fa1d5a6869be9',
        thumbnailUrl: 'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1600&q=80'
      }
    ]
  },
  {
    title: 'Հոլովակներ',
    videos: [
      {
        title: 'Ուսուցողական տեսանյութ',
        category: 'Կրթություն',
        videoUrl: 'https://player.vimeo.com/external/459389137.hd.mp4?s=865d2c0ec77b5d11f419a9a5b4f26e4f9b2c35fb',
        thumbnailUrl: 'https://images.unsplash.com/photo-1579187707643-35646d22b596?auto=format&fit=crop&w=1600&q=80'
      },
      {
        title: 'Բրենդի պատմություն',
        category: 'Բիզնես',
        videoUrl: 'https://player.vimeo.com/external/403661701.hd.mp4?s=42e2cc5f0b63c5c86f8d6f8f8c1a7d2d8c7c6d6d',
        thumbnailUrl: 'https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=1600&q=80'
      }
    ]
  },
  {
    title: 'Նկարներ',
    videos: [
      {
        title: 'Դասընթացի լուսանկարներ',
        category: 'Կրթություն',
        videoUrl: '',
        thumbnailUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1600&q=80'
      },
      {
        title: 'Նկարահանման պահեր',
        category: 'Աշխատանքային',
        videoUrl: '',
        thumbnailUrl: 'https://images.unsplash.com/photo-1581591524425-c7e0978865fc?auto=format&fit=crop&w=1600&q=80'
      }
    ]
  }
];