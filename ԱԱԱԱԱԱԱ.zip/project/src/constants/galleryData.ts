import { GalleryItem } from '../types/gallery';

export const galleryData: GalleryItem[] = [
  {
    id: 'gallery-1',
    type: 'video',
    url: 'https://player.vimeo.com/video/735543529',
    thumbnailUrl: 'https://i.ibb.co/Yj7XqgL/image.jpg',
    title: 'Դասընթացի հիմնական պահեր'
  },
  {
    id: 'gallery-2',
    type: 'video',
    url: 'https://player.vimeo.com/video/735543749',
    thumbnailUrl: 'https://i.ibb.co/0QKS4Jw/image.jpg',
    title: 'Ուսանողների աշխատանքներ'
  },
  {
    id: 'gallery-3',
    type: 'video',
    url: 'https://player.vimeo.com/video/735544025',
    thumbnailUrl: 'https://i.ibb.co/Lkn7rkJ/image.jpg',
    title: 'Բրենդային ռիլ'
  },
  {
    id: 'gallery-4',
    type: 'image',
    url: 'https://i.ibb.co/C6NLCZP/image.jpg',
    title: 'Դասընթացի լուսանկարներ'
  },
  {
    id: 'gallery-5',
    type: 'image',
    url: 'https://i.ibb.co/8X5HqQV/image.jpg',
    title: 'Նկարահանման պահեր'
  },
  {
    id: 'gallery-6',
    type: 'image',
    url: 'https://i.ibb.co/k4B3f5k/image.jpg',
    title: 'Թիմային աշխատանք'
  }
];