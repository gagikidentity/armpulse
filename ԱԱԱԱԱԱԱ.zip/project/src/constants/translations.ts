export const translations = {
  nav: {
    home: "Գլխավոր",
    services: "Ծառայություններ",
    team: "Մեր թիմը",
    contact: "Կապ"
  },
  hero: {
    title: "ArmPulse Production",
    description: "Գրավիչ ռիլերի պատրաստում և ռիլմեյքինգի դասընթացներ",
    buttons: {
      services: "Մեր Ծառայությունները",
      portfolio: "Պատվիրել հիմա"
    }
  },
  services: {
    title: "Մեր Ծառայությունները",
    subtitle: "Պրոֆեսիոնալ վիդեո ծառայություններ 30% զեղչով",
    items: [
      {
        title: "Պրոֆեսիոնալ Վիդեո Նկարահանում",
        description: "Բարձրորակ տեսանյութերի պատրաստում ժամանակակից սարքավորումներով",
        price: "Սկսած 500$-ից"
      },
      {
        title: "Վիդեո Մոնտաժ",
        description: "Պրոֆեսիոնալ մոնտաժ 3-օրյա ժամկետում",
        price: "Սկսած 300$-ից"
      },
      {
        title: "Սարքավորումների Վարձույթ",
        description: "Պրոֆեսիոնալ տեխնիկա՝ ներառյալ Panasonic Lumix S5 IIX",
        price: "Օրական սակագներ"
      }
    ]
  },
  contact: {
    title: "Կապ Մեզ Հետ",
    subtitle: "Կապվեք մեզ հետ հարցերի, պատվերների և գրանցումների համար",
    form: {
      name: "Անուն",
      email: "Էլ․ հասցե",
      message: "Հաղորդագրություն",
      submit: "Ուղարկել"
    },
    info: {
      phone: "Հեռախոս",
      email: "Էլ․ հասցե",
      location: "Հասցե",
      locationText: "Երևան, Հայաստան"
    }
  },
  footer: {
    copyright: "© 2024 ArmPulse Production։ Բոլոր իրավունքները պաշտպանված են։"
  }
};