export interface TeamMember {
  id: string;
  name: string;
  role: string;
  image: string;
  specialties?: Array<{
    icon: any;
    text: string;
  }>;
}