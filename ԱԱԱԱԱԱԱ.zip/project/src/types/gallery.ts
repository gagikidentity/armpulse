export interface GalleryItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnailUrl?: string;
  title?: string;
}

export interface GallerySection {
  id: string;
  title: string;
  items: GalleryItem[];
}