export interface VideoData {
  title: string;
  category: string;
  videoUrl: string;
  thumbnailUrl: string;
}

export interface PortfolioCategory {
  title: string;
  videos: VideoData[];
}