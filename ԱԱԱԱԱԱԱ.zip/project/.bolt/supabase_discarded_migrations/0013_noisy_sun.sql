/*
  # Team Members Database Setup
  
  1. Tables
    - team_members: Stores basic member information
    - team_member_images: Stores image URLs for team members
  
  2. Storage
    - Creates team-images bucket for storing member photos
  
  3. Security
    - Enables RLS on all tables
    - Sets up appropriate access policies
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "storage";

-- Create team_members table
CREATE TABLE IF NOT EXISTS team_members (
  id text PRIMARY KEY,
  name text NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create team_member_images table
CREATE TABLE IF NOT EXISTS team_member_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id text REFERENCES team_members(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_member_images ENABLE ROW LEVEL SECURITY;

-- Create storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('team-images', 'team-images', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Allow public read access to team_members"
  ON team_members FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage team_members"
  ON team_members FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public read access to team_member_images"
  ON team_member_images FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage team_member_images"
  ON team_member_images FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create storage policies
CREATE POLICY "Allow public read access to team-images"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'team-images');

CREATE POLICY "Allow authenticated users to manage team-images"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'team-images')
  WITH CHECK (bucket_id = 'team-images');

-- Insert initial team members
INSERT INTO team_members (id, name, role)
VALUES 
  ('member1', 'Գագիկ Հարությունյան', 'Հիմնադիր'),
  ('member2', 'Նոննա Ալավերդյան', 'Դիզայներ'),
  ('member3', 'Պավել Տերտերյան', 'Ռիլմեյքեր')
ON CONFLICT (id) DO NOTHING;