/*
  # Fix Storage and RLS Policies

  1. Changes
    - Drop and recreate storage policies with proper permissions
    - Add missing RLS policies for storage.objects
    - Fix policy conditions for authenticated users
    
  2. Security
    - Ensure proper access control for both public and authenticated users
    - Maintain data integrity while fixing permissions
*/

-- Enable RLS for storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing storage policies to recreate them properly
DROP POLICY IF EXISTS "Allow public read access to team-images" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to manage team-images" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read access to portfolio-media" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to manage portfolio-media" ON storage.objects;

-- Create proper storage policies with correct permissions
CREATE POLICY "Allow public read access to team-images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'team-images');

CREATE POLICY "Allow authenticated users to manage team-images"
ON storage.objects
FOR ALL
TO authenticated
USING (bucket_id = 'team-images')
WITH CHECK (bucket_id = 'team-images');

CREATE POLICY "Allow public read access to portfolio-media"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'portfolio-media');

CREATE POLICY "Allow authenticated users to manage portfolio-media"
ON storage.objects
FOR ALL
TO authenticated
USING (bucket_id = 'portfolio-media')
WITH CHECK (bucket_id = 'portfolio-media');

-- Ensure storage buckets exist and are public
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('team-images', 'team-images', true),
  ('portfolio-media', 'portfolio-media', true)
ON CONFLICT (id) DO UPDATE SET public = true;