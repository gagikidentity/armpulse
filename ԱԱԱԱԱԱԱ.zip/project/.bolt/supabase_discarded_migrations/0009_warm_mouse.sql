/*
  # Fix Storage Policies

  1. Storage
    - Create storage extension
    - Create team-images bucket
    - Set up proper RLS policies for storage
*/

-- Enable storage extension
CREATE EXTENSION IF NOT EXISTS "storage";

-- Create bucket if not exists
INSERT INTO storage.buckets (id, name, public)
VALUES ('team-images', 'team-images', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies to recreate them properly
DROP POLICY IF EXISTS "Allow public read access to team-images" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to upload team-images" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to update team-images" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to delete team-images" ON storage.objects;

-- Create proper storage policies
CREATE POLICY "Allow public read access to team-images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'team-images');

CREATE POLICY "Allow authenticated users to manage team-images"
ON storage.objects FOR ALL
TO authenticated
USING (bucket_id = 'team-images')
WITH CHECK (bucket_id = 'team-images');

-- Ensure RLS is enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;