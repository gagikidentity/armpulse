/*
  # Complete Database Setup

  1. Tables
    - team_members
    - team_member_images
    - portfolio_categories
    - portfolio_items

  2. Storage
    - team-images bucket
    - portfolio-media bucket

  3. Security
    - RLS policies for all tables
    - Storage policies for both buckets
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "storage";

-- Create team_members table
CREATE TABLE IF NOT EXISTS team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create team_member_images table
CREATE TABLE IF NOT EXISTS team_member_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid REFERENCES team_members(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create portfolio_categories table
CREATE TABLE IF NOT EXISTS portfolio_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create portfolio_items table
CREATE TABLE IF NOT EXISTS portfolio_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES portfolio_categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  video_url text,
  thumbnail_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_member_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_items ENABLE ROW LEVEL SECURITY;

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('team-images', 'team-images', true),
  ('portfolio-media', 'portfolio-media', true)
ON CONFLICT (id) DO NOTHING;

-- Create RLS policies for team_members
CREATE POLICY "Allow public read access to team_members"
  ON team_members FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage team_members"
  ON team_members FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create RLS policies for team_member_images
CREATE POLICY "Allow public read access to team_member_images"
  ON team_member_images FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage team_member_images"
  ON team_member_images FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create RLS policies for portfolio_categories
CREATE POLICY "Allow public read access to portfolio_categories"
  ON portfolio_categories FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage portfolio_categories"
  ON portfolio_categories FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create RLS policies for portfolio_items
CREATE POLICY "Allow public read access to portfolio_items"
  ON portfolio_items FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage portfolio_items"
  ON portfolio_items FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create storage policies
CREATE POLICY "Allow public read access to team-images"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'team-images');

CREATE POLICY "Allow authenticated users to manage team-images"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'team-images')
  WITH CHECK (bucket_id = 'team-images');

CREATE POLICY "Allow public read access to portfolio-media"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'portfolio-media');

CREATE POLICY "Allow authenticated users to manage portfolio-media"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'portfolio-media')
  WITH CHECK (bucket_id = 'portfolio-media');

-- Insert initial team members
INSERT INTO team_members (id, name, role)
VALUES 
  ('member1', 'Գագիկ Հարությունյան', 'Հիմնադիր'),
  ('member2', 'Նոննա Ալավերդյան', 'Դիզայներ'),
  ('member3', 'Պավել Տերտերյան', 'Ռիլմեյքեր')
ON CONFLICT (id) DO NOTHING;

-- Insert initial portfolio categories
INSERT INTO portfolio_categories (title)
VALUES 
  ('Դասընթացներ'),
  ('Ռիլեր'),
  ('Հոլովակներ'),
  ('Նկարներ')
ON CONFLICT DO NOTHING;